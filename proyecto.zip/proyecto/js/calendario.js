document.addEventListener('DOMContentLoaded', function() {
    verificarSesion();
});

function verificarSesion() {
    const sesionActiva = sessionStorage.getItem('sesionActiva');
    const usuarioActivo = sessionStorage.getItem('usuarioActivo');
    
    if (!sesionActiva || sesionActiva !== 'true') {
        alert('Debes iniciar sesión primero');
        window.location.href = 'index.html';
    } else {
        console.log('Sesión activa:', usuarioActivo);
    }
}

function cerrarSesion() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        sessionStorage.removeItem('usuarioActivo');
        sessionStorage.removeItem('sesionActiva');
        alert('Sesión cerrada exitosamente');
        window.location.href = 'index.html';
    }
}

window.cerrarSesion = cerrarSesion;

const calendarDays = document.getElementById("calendar-days");
const calendarTitle = document.getElementById("calendar-title");
const filterSelect = document.getElementById("filter");
const tituloEventos = document.getElementById("titulo-eventos");
const modal = document.getElementById("modal-evento");

let date = new Date();
let month = date.getMonth();
let year = date.getFullYear();

const eventos = [
    { date: "2025-11-18", title: "Curso de inglés", hora: "10:00" },
    { date: "2025-11-20", title: "Curso de informática", hora: "14:00" }
];

const meses = ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
const diasCompletos = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];

// Modal functions
document.getElementById("btn-nuevo-evento").onclick = () => {
    const ahora = new Date();
    document.getElementById("evento-fecha").value = ahora.toISOString().split('T')[0];
    document.getElementById("evento-hora").value = ahora.toTimeString().slice(0,5);
    document.getElementById("evento-titulo").value = "";
    modal.style.display = "block";
};

document.querySelector(".cerrar").onclick = () => modal.style.display = "none";
document.getElementById("btn-cancelar").onclick = () => modal.style.display = "none";

window.onclick = (event) => {
    if (event.target == modal) modal.style.display = "none";
};

document.getElementById("form-evento").onsubmit = (e) => {
    e.preventDefault();
    
    const titulo = document.getElementById("evento-titulo").value;
    const fecha = document.getElementById("evento-fecha").value;
    const hora = document.getElementById("evento-hora").value;
    
    if (titulo && fecha) {
        eventos.push({ 
            date: fecha, 
            title: titulo, 
            hora: hora || "00:00" 
        });
        
        modal.style.display = "none";
        filterSelect.value === 'dia' ? actualizarVistaDia() : renderCalendar();
    }
};

filterSelect.addEventListener('change', function() {
    if (this.value === 'dia') {
        document.querySelector('.calendar-wrapper').classList.add('vista-dia');
        actualizarVistaDia();
        tituloEventos.textContent = "Eventos del día";
    } else {
        document.querySelector('.calendar-wrapper').classList.remove('vista-dia');
        renderCalendar();
        tituloEventos.textContent = "Eventos del mes";
    }
});

function actualizarVistaDia() {
    document.getElementById('dia-semana').textContent = diasCompletos[date.getDay()];
    document.getElementById('dia-numero').textContent = date.getDate();
    document.getElementById('dia-mes').textContent = `${meses[date.getMonth()]} ${year}`;
    cargarEventos();
}

function cambiarDia(dias) {
    date.setDate(date.getDate() + dias);
    actualizarVistaDia();
}

function irHoy() {
    date = new Date();
    actualizarVistaDia();
}

function renderCalendar() {
    calendarDays.innerHTML = "";
    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    calendarTitle.textContent = `${meses[month]} ${year}`;

    for (let i = 0; i < firstDay; i++) {
        calendarDays.appendChild(document.createElement("div"));
    }

    for (let d = 1; d <= lastDate; d++) {
        const dayDiv = document.createElement("div");
        dayDiv.textContent = d;
        const key = `${year}-${(month + 1).toString().padStart(2, "0")}-${d.toString().padStart(2, "0")}`;
        if (eventos.some(e => e.date === key)) dayDiv.classList.add("event-day");
        calendarDays.appendChild(dayDiv);
    }

    const remainingCells = 42 - (firstDay + lastDate);
    for (let i = 0; i < remainingCells; i++) {
        calendarDays.appendChild(document.createElement("div"));
    }
    
    cargarEventos();
}

document.getElementById("prev-month").onclick = () => {
    month = month > 0 ? month - 1 : 11;
    if (month === 11) year--;
    date = new Date(year, month, 1);
    renderCalendar();
};

document.getElementById("next-month").onclick = () => {
    month = month < 11 ? month + 1 : 0;
    if (month === 0) year++;
    date = new Date(year, month, 1);
    renderCalendar();
};

document.getElementById("prev-day").onclick = () => cambiarDia(-1);
document.getElementById("next-day").onclick = () => cambiarDia(1);
document.getElementById("today-day").onclick = irHoy;

function cargarEventos() {
    const list = document.getElementById("event-list");
    list.innerHTML = "";

    let eventosFiltrados = filterSelect.value === 'dia' 
        ? eventos.filter(ev => ev.date === date.toISOString().split('T')[0])
        : eventos.filter(ev => ev.date.startsWith(`${year}-${(month + 1).toString().padStart(2, "0")}`));

    eventosFiltrados.sort((a, b) => a.date === b.date ? a.hora.localeCompare(b.hora) : a.date.localeCompare(b.date));

    if (eventosFiltrados.length === 0) {
        list.innerHTML = "<div class='evento-item'>No hay eventos programados</div>";
        return;
    }

    eventosFiltrados.forEach(ev => {
        const fecha = new Date(ev.date);
        const div = document.createElement("div");
        div.className = "evento-item";
        div.innerHTML = `<strong>${ev.title}</strong><br><small>${fecha.getDate()} ${meses[fecha.getMonth()].toLowerCase()} ${fecha.getFullYear()}${ev.hora !== "00:00" ? ` a las ${ev.hora}` : ''}</small>`;
        list.appendChild(div);
    });
}

renderCalendar();