document.getElementById("btnIngresar").addEventListener("click", function(event) {
    event.preventDefault(); 
    
    const user = document.getElementById("usuario").value.trim();
    const pass = document.getElementById("contrasena").value.trim();
    
    const userError = document.getElementById('usuario-error');
    const passError = document.getElementById('contrasena-error');
    const generalError = document.getElementById('general-error');
    
    userError.textContent = "";
    passError.textContent = "";
    generalError.textContent = "";
    
    let isValid = true; 
    
    if (user === "") {
        userError.textContent = "¡Debes ingresar tu Usuario!";
        isValid = false;
    }
    
    if (pass === "") {
        passError.textContent = "¡Debes ingresar tu Contraseña!";
        isValid = false;
    }
    
    if (!isValid) {
        generalError.textContent = "Por favor, completa los campos requeridos.";
        return; 
    }
    
    sessionStorage.setItem('usuarioActivo', user);
    sessionStorage.setItem('sesionActiva', 'true');
    
    window.location.href = 'dashboard.html';
});