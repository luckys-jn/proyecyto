document.addEventListener('DOMContentLoaded', function() {
    
    verificarSesion();
    
    const btnPerfil = document.getElementById('btnPerfil');
    const btnCalendario = document.getElementById('btnCalendario');
    const btnCampana = document.getElementById('btnCampana');
    
    btnPerfil.addEventListener('click', function() {
        console.log('Navegando a Perfil...');
        window.location.href = 'perfil.html';
    });
    
    btnCalendario.addEventListener('click', function() {
        console.log('Navegando a Calendario...');
        window.location.href = 'calendario.html';
    });
    
    btnCampana.addEventListener('click', function() {
        console.log('Navegando a Notificaciones...');
        window.location.href = 'notificaciones.html';
    });
    
    const newsCards = document.querySelectorAll('.news-card');
    
    newsCards.forEach(card => {
        card.addEventListener('click', function() {
            console.log('Noticia clickeada:', this.querySelector('.news-title').textContent);
            alert('Funcionalidad de noticias próximamente...');
        });
    });
    
    mostrarBienvenida();
    
    verificarNotificaciones();
});

function verificarNotificaciones() {
    const btnCampana = document.getElementById('btnCampana');
    
    const tieneNotificaciones = true;
    
    if (tieneNotificaciones && btnCampana) {
        console.log('Tienes notificaciones pendientes');
    }
}

function verificarSesion() {
    const sesionActiva = sessionStorage.getItem('sesionActiva');
    const usuarioActivo = sessionStorage.getItem('usuarioActivo');
    
    if (!sesionActiva || sesionActiva !== 'true') {
        alert('Debes iniciar sesión primero');
        window.location.href = 'index.html';
    } else {
        console.log('Sesión activa:', usuarioActivo);
    }
}

function mostrarBienvenida() {
    const usuarioActivo = sessionStorage.getItem('usuarioActivo');
    
    if (usuarioActivo) {
        console.log('Bienvenido:', usuarioActivo);
    }
}

function cerrarSesion() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        sessionStorage.removeItem('usuarioActivo');
        sessionStorage.removeItem('sesionActiva');
        alert('Sesión cerrada exitosamente');
        window.location.href = 'index.html';
    }
}

window.cerrarSesion = cerrarSesion;