document.addEventListener('DOMContentLoaded', function() {
    verificarSesion();
    cargarNotificaciones();
});

function verificarSesion() {
    const sesionActiva = sessionStorage.getItem('sesionActiva');
    const usuarioActivo = sessionStorage.getItem('usuarioActivo');
    
    if (!sesionActiva || sesionActiva !== 'true') {
        alert('Debes iniciar sesión primero');
        window.location.href = 'index.html';
    } else {
        console.log('Sesión activa:', usuarioActivo);
    }
}

function cerrarSesion() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        sessionStorage.removeItem('usuarioActivo');
        sessionStorage.removeItem('sesionActiva');
        alert('Sesión cerrada exitosamente');
        window.location.href = 'index.html';
    }
}

window.cerrarSesion = cerrarSesion;

const datos = [
    {
        titulo: "Información administrativa",
        fecha: "02 Nov 2025",
        texto: "Tu recibo de pago del periodo académico ya está disponible."
    },
    {
        titulo: "Ranking horas libres",
        fecha: "03 Nov 2025",
        texto: "¡Estás en el 3° puesto! ¡Sigue así!"
    },
    {
        titulo: "Horas libres",
        fecha: "04 Nov 2025",
        texto: "Has llegado a 41 horas ¡Estás cerca!"
    },
    {
        titulo: "Biblioteca",
        fecha: "05 Nov 2025",
        texto: "Tu préstamo del material bibliográfico está por vencer."
    },
    {
        titulo: "Exploraciones y decisiones",
        fecha: "06 Nov 2025",
        texto: "Describe los enfoques considerados, las decisiones finalmente tomadas y por qué."
    },
    {
        titulo: "Actualización académica",
        fecha: "07 Nov 2025",
        texto: "Un profesor ha compartido un nuevo anuncio importante para tu clase."
    },
    {
        titulo: "Vida estudiantil y bienestar",
        fecha: "08 Nov 2025",
        texto: "Hay cupos disponibles para asesoría psicológica y acompañamiento académico."
    }
];

const contenedor = document.getElementById("notificacionesLista");

function cargarNotificaciones() {
    datos.forEach(n => {
        const item = document.createElement("div");
        item.classList.add("notificacion-item");
        item.innerHTML = `
            <span class="notif-titulo">${n.titulo}</span>
            <span class="notif-fecha">${n.fecha}</span>
            <span class="notif-texto">${n.texto}</span>
        `;
        contenedor.appendChild(item);
    });
}