document.addEventListener('DOMContentLoaded', function() {
    verificarSesion();
    
});

function verificarSesion() {
    const sesionActiva = sessionStorage.getItem('sesionActiva');
    const usuarioActivo = sessionStorage.getItem('usuarioActivo');
    
    if (!sesionActiva || sesionActiva !== 'true') {
        alert('Debes iniciar sesión primero');
        window.location.href = 'index.html';
    } else {
        console.log('Sesión activa:', usuarioActivo);
    }
}

function cerrarSesion() {
    if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
        sessionStorage.removeItem('usuarioActivo');
        sessionStorage.removeItem('sesionActiva');
        alert('Sesión cerrada exitosamente');
        window.location.href = 'index.html';
    }
}
window.cerrarSesion = cerrarSesion;
